package com.example.tictactoebeta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class playerNames extends AppCompatActivity {
    public Button jtbn2;
    public EditText p1n, p2n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_names);
        p1n = (EditText) findViewById(R.id.PlayerOneName);
        p2n = (EditText) findViewById(R.id.PlayerTwoName);
        jtbn2 = (Button) findViewById(R.id.btn2);
        jtbn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pName1 = p1n.getText().toString();
                String pName2 = p2n.getText().toString();
                if(p1n.getText().toString().equals("")){
                    Toast.makeText(playerNames.this, "Enter Player Names!!", Toast.LENGTH_SHORT).show();
                }
                else if(p2n.getText().toString().equals("")){
                    Toast.makeText(playerNames.this, "Enter Player Names!!", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent it = new Intent(playerNames.this, tttGame.class);
                    it.putExtra("p1n1", pName1);
                    it.putExtra("p2n2", pName2);
                    startActivity(it);
                }
            }
        });
    }
}